/**
 * 
 */
package br.udesc.wutb.listener;

import br.udesc.wutb.activity.ActivityGame;

/**
 * @author mantau
 * 
 */
public class ListenerTerminal {
	// UI Elements
	

	public ListenerTerminal(ActivityGame activity) {
		//TODO
	}
	
	public void addListeners() {
		/*sendMessage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				submitMessage();

			}
		});*/
	}
}
