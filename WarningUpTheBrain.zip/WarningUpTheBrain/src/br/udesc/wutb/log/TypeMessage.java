/**
 * 
 */
package br.udesc.wutb.log;

/**
 * @author mantau
 *
 */
public enum TypeMessage {
	ACTION,
	NOTIFICATION,
	CACHE_COHERENCE,
	ERROR,
	WARNING,
	CHAT;
}
